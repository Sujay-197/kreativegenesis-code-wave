import React, { useState, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Sparkles, Code2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import ChatInterface, { Message } from '../components/ChatInterface';
import BlueprintPanel, { RequirementsState } from '../components/BlueprintPanel';
import RequirementsSummary from '../components/RequirementsSummary';
import GenerationProgress from '../components/GenerationProgress';
import AppPreview from '../components/AppPreview';
import ModeCard from '../components/ModeCard';
import {
  initialRequirements,
  processUserMessage,
  getOpeningMessage,
  generateAppHTML,
  getOverallConfidence,
} from '../lib/aiEngine';

type BuilderStage = 'mode-select' | 'chat' | 'summary' | 'generating' | 'preview';

const TOTAL_QUESTIONS = 7;

const generationStages = [
  'Analyzing requirements...',
  'Selecting template...',
  'Generating UI structure...',
  'Wiring business logic...',
  'Finalizing your app...',
];

export default function Builder() {
  const [stage, setStage] = useState<BuilderStage>('mode-select');
  const [mode, setMode] = useState<'simple' | 'expert'>('simple');
  const [messages, setMessages] = useState<Message[]>([]);
  const [requirements, setRequirements] = useState<RequirementsState>(initialRequirements());
  const [appName, setAppName] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [questionCount, setQuestionCount] = useState(0);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [generationStage, setGenerationStage] = useState(generationStages[0]);
  const [generatedHTML, setGeneratedHTML] = useState('');
  const conversationHistory = useRef<{ role: 'user' | 'ai'; content: string }[]>([]);

  const selectMode = useCallback((selectedMode: 'simple' | 'expert') => {
    setMode(selectedMode);
    const opening = getOpeningMessage(selectedMode);
    const openingMsg: Message = {
      id: crypto.randomUUID(),
      role: 'ai',
      content: opening,
      timestamp: new Date(),
    };
    conversationHistory.current = [{ role: 'ai', content: opening }];
    setMessages([openingMsg]);
    setStage('chat');
  }, []);

  const handleSend = useCallback(
    (text: string) => {
      if (isAiLoading) return;

      const userMsg: Message = {
        id: crypto.randomUUID(),
        role: 'user',
        content: text,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, userMsg]);
      setIsAiLoading(true);

      setTimeout(() => {
        const { nextQuestion, updatedRequirements, appName: detectedName, isReady } = processUserMessage(
          text,
          conversationHistory.current,
          requirements,
          mode
        );

        conversationHistory.current = [
          ...conversationHistory.current,
          { role: 'user', content: text },
        ];

        setRequirements(updatedRequirements);
        if (detectedName) setAppName(detectedName);
        setQuestionCount((c) => c + 1);

        if (isReady) {
          const summaryMsg: Message = {
            id: crypto.randomUUID(),
            role: 'ai',
            content:
              mode === 'simple'
                ? "I think I have a solid understanding of what you need. Let me show you a summary of your app before I build it."
                : "Requirements confidence threshold reached. Review the spec below before initiating generation.",
            timestamp: new Date(),
          };
          conversationHistory.current = [
            ...conversationHistory.current,
            { role: 'ai', content: summaryMsg.content },
          ];
          setMessages((prev) => [...prev, summaryMsg]);
          setIsAiLoading(false);
          setTimeout(() => setStage('summary'), 800);
        } else {
          const aiMsg: Message = {
            id: crypto.randomUUID(),
            role: 'ai',
            content: nextQuestion,
            timestamp: new Date(),
          };
          conversationHistory.current = [
            ...conversationHistory.current,
            { role: 'ai', content: nextQuestion },
          ];
          setMessages((prev) => [...prev, aiMsg]);
          setIsAiLoading(false);
        }
      }, 900 + Math.random() * 600);
    },
    [isAiLoading, requirements, mode]
  );

  const handleConfirmGenerate = useCallback(() => {
    setStage('generating');
    setGenerationProgress(0);

    let stageIndex = 0;
    const interval = setInterval(() => {
      setGenerationProgress((p) => {
        const next = p + 4 + Math.random() * 6;
        const clamped = Math.min(next, 95);
        const newStageIndex = Math.floor((clamped / 100) * generationStages.length);
        if (newStageIndex !== stageIndex && newStageIndex < generationStages.length) {
          stageIndex = newStageIndex;
          setGenerationStage(generationStages[stageIndex]);
        }
        return clamped;
      });
    }, 200);

    setTimeout(() => {
      clearInterval(interval);
      setGenerationProgress(100);
      setGenerationStage('App ready!');
      const html = generateAppHTML(requirements, appName || 'My App', mode);
      setGeneratedHTML(html);
      setTimeout(() => setStage('preview'), 500);
    }, 4500);
  }, [requirements, appName, mode]);

  const handleRestart = useCallback(() => {
    setStage('mode-select');
    setMessages([]);
    setRequirements(initialRequirements());
    setAppName('');
    setQuestionCount(0);
    setGenerationProgress(0);
    setGeneratedHTML('');
    conversationHistory.current = [];
  }, []);

  const confidence = getOverallConfidence(requirements);

  return (
    <div className="min-h-screen bg-forge-dark flex flex-col">
      <div className="flex items-center justify-between px-6 py-4 border-b border-forge-border bg-forge-darker">
        <Link
          to="/"
          className="flex items-center gap-2 text-forge-muted hover:text-white transition-colors duration-200 text-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-forge-accent rounded"
        >
          <ArrowLeft size={16} />
          Back to home
        </Link>
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-md bg-gradient-to-br from-forge-accent to-forge-violet flex items-center justify-center">
            <Sparkles size={12} className="text-white" />
          </div>
          <span className="font-heading font-bold text-white text-sm">
            AppForge <span className="text-forge-accent">AI</span>
          </span>
        </div>
        {stage !== 'mode-select' && (
          <div className="flex items-center gap-2">
            <span className="text-xs text-forge-muted">
              {mode === 'simple' ? 'Simple Mode' : 'Expert Mode'}
            </span>
            <button
              onClick={() => {
                const newMode = mode === 'simple' ? 'expert' : 'simple';
                setMode(newMode);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-forge-border text-forge-muted hover:text-white hover:border-forge-muted text-xs transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-forge-accent"
            >
              <Code2 size={12} />
              Switch
            </button>
          </div>
        )}
        {stage === 'mode-select' && <div className="w-24" />}
      </div>

      <div className="flex-1 flex overflow-hidden">
        <AnimatePresence mode="wait">
          {stage === 'mode-select' && (
            <motion.div
              key="mode-select"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.3 }}
              className="flex-1 flex items-center justify-center p-8"
            >
              <div className="w-full max-w-3xl">
                <div className="text-center mb-12">
                  <h1 className="font-heading text-4xl font-bold text-white mb-3">
                    How would you like to build?
                  </h1>
                  <p className="text-forge-muted text-lg">
                    Choose the experience that fits you best. You can switch anytime.
                  </p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <ModeCard
                    mode="simple"
                    title="Simple Mode"
                    subtitle="For everyone"
                    description="Describe your idea in plain language. I'll ask friendly questions and handle all the technical details."
                    features={[
                      'Jargon-free conversation',
                      'Visual blueprint updates live',
                      'Ready in under 15 minutes',
                      'No technical knowledge needed',
                    ]}
                    icon={<Sparkles size={12} />}
                    accentClass="bg-forge-accent"
                    borderClass="border-forge-accent/30 hover:border-forge-accent/60"
                    badgeClass="bg-forge-accent/15 text-forge-accent"
                    onSelect={() => selectMode('simple')}
                  />
                  <ModeCard
                    mode="expert"
                    title="Expert Mode"
                    subtitle="For developers"
                    description="Speak in technical shorthand. Define entities, routes, and logic precisely. Maximum speed and control."
                    features={[
                      'Technical spec language',
                      'Entity & route definitions',
                      'Architecture-aware questions',
                      'Ready in under 10 minutes',
                    ]}
                    icon={<Code2 size={12} />}
                    accentClass="bg-forge-emerald"
                    borderClass="border-forge-emerald/30 hover:border-forge-emerald/60"
                    badgeClass="bg-forge-emerald/15 text-forge-emerald"
                    onSelect={() => selectMode('expert')}
                  />
                </div>
              </div>
            </motion.div>
          )}

          {(stage === 'chat' || stage === 'summary') && (
            <motion.div
              key="chat-layout"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="flex-1 flex overflow-hidden"
            >
              <div className="flex-1 flex flex-col border-r border-forge-border overflow-hidden">
                <div className="flex-1 overflow-hidden">
                  <ChatInterface
                    messages={messages}
                    onSend={handleSend}
                    isLoading={isAiLoading}
                    mode={mode}
                    disabled={stage === 'summary'}
                  />
                </div>
                <AnimatePresence>
                  {stage === 'summary' && (
                    <motion.div
                      initial={{ opacity: 0, y: 16 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 16 }}
                      transition={{ duration: 0.3 }}
                      className="p-4 border-t border-forge-border"
                    >
                      <RequirementsSummary
                        requirements={requirements}
                        appName={appName}
                        mode={mode}
                        onConfirm={handleConfirmGenerate}
                        onEdit={() => setStage('chat')}
                      />
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <div className="w-80 xl:w-96 flex-shrink-0 overflow-y-auto bg-forge-darker">
                <BlueprintPanel
                  requirements={requirements}
                  questionCount={questionCount}
                  totalQuestions={TOTAL_QUESTIONS}
                  mode={mode}
                  appName={appName}
                />
              </div>
            </motion.div>
          )}

          {stage === 'generating' && (
            <motion.div
              key="generating"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="flex-1"
            >
              <GenerationProgress stage={generationStage} progress={generationProgress} />
            </motion.div>
          )}

          {stage === 'preview' && (
            <motion.div
              key="preview"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="flex-1 p-6 overflow-hidden flex flex-col"
            >
              <AppPreview
                htmlContent={generatedHTML}
                appName={appName || 'My App'}
                onRestart={handleRestart}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {stage === 'chat' && (
        <div className="px-6 py-2 border-t border-forge-border bg-forge-darker flex items-center justify-between">
          <span className="text-xs text-forge-muted">
            Understanding your requirements — {Math.round(confidence)}% confident
          </span>
          {confidence >= 60 && questionCount >= 5 && (
            <button
              onClick={() => setStage('summary')}
              className="text-xs text-forge-accent hover:text-forge-accent-hover transition-colors duration-200 font-medium focus:outline-none focus-visible:ring-2 focus-visible:ring-forge-accent rounded"
            >
              I'm ready to generate →
            </button>
          )}
        </div>
      )}
    </div>
  );
}